-- Databricks notebook source
-- MAGIC %md
-- MAGIC Load the data into a dataframe using Python:

-- COMMAND ----------

-- MAGIC %python
-- MAGIC # Load the data into a dataframe
-- MAGIC df = spark.read.format("csv")\
-- MAGIC     .option("header", True)\
-- MAGIC     .option("inferSchema", True)\
-- MAGIC     .load("abfss://sparksql@storaccsqlforbigde.dfs.core.windows.net/source/raw_data")
-- MAGIC
-- MAGIC # Examine the data using .display()
-- MAGIC df.display()
-- MAGIC
-- MAGIC # Create a temp view named orders_temp, but it will only available for the current notebook session (however, global temp views will remain until the cluster is deleted/restarted)
-- MAGIC df.createOrReplaceTempView("orders_temp")

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # Spark SQL Basics

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Temp Views
-- MAGIC Convert a dataframe into a temporary view and use it for SQL querying using df.createOrReplaceTempView("orders_temp")
-- MAGIC
-- MAGIC ### Temp Views vs. Global Temp Views
-- MAGIC A temp view only lasts in the current notebook session and will not be available to anyone else other than the person who created it on their own machine. A global temp view will be available to anyone else's session until the cluster is shut down, deleted, or restarted.
-- MAGIC
-- MAGIC ### How to select from a global temp view
-- MAGIC SELECT * FROM global_temp.(name of global temp view)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC How to write SQL queries in code blocks in a notebook:
-- MAGIC 1. Create a new code block and change the language to SQL by either clicking the language "Python" and changing it to SQL or typing "%sql" at the top of the code block
-- MAGIC 2. Change the default language of the notebook (note: if you need other languages like Python, you need to add %python at the top of the code block)

-- COMMAND ----------

SELECT * FROM orders_temp;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Creating Global Temp Views

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #df.createOrReplaceGlobalTempView("orders_global_temp")
-- MAGIC # Note: global temp views aren't supported on serverless clusters (so don't run this cell's code if the notebook is using serverless compute),
-- MAGIC # and also global temp views can conflict with other global temp views

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Managed Tables
-- MAGIC - Metastore stores all of the metadata (information about the data) -> Examples: table name, schema, database name, catalog name, etc.
-- MAGIC - Databricks needs a managed/external/cloud location for data storage (the metastore needs an external data storage location for the actual data itself) because it builds the tables on top of the data itself (usually the files containing the data) as metadata instead of storing the data in Databricks (this also applies to other PySpark frameworks)
-- MAGIC - When you create a managed table, the data will go to the managed cloud storage (the managed/external location provided when creating the metastore, owned by the metastore), and when you run the command "DROP TABLE orders", it will delete both the metadata and the data itself since the metastore has the permissions to do so.
-- MAGIC - Useful if the data doesn't need to be kept even when the table is dropped
-- MAGIC
-- MAGIC ### External Tables
-- MAGIC - All the metadata gets saved into the metastore
-- MAGIC - All the data doesn't get saved into the managed cloud storage
-- MAGIC - Running the command "DROP TABLE orders" will only delete the metadata. It won't delete the data itself since the metastore doesn't have the permissions to do so.
-- MAGIC - Useful if the requirement is to keep the data even when the table is dropped

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # **External vs. Managed Tables**
-- MAGIC Concepts:
-- MAGIC - CTAS (Create Table As Select) -> assuming there is already a table/view, use the query (DDL) "Create Table AS SELECT * FROM view;"

-- COMMAND ----------

-- Create a catalog
CREATE CATALOG IF NOT EXISTS sparksql_cata;

-- Create a schema
CREATE SCHEMA IF NOT EXISTS sparksql_cata.sparksql_schema;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Managed Tables

-- COMMAND ----------

-- Create the orders_man table
CREATE TABLE sparksql_cata.sparksql_schema.order_man
AS (
    SELECT *
    FROM orders_temp
);

-- COMMAND ----------

-- Drop the orders_man table
DROP TABLE sparksql_cata.sparksql_schema.order_man;

-- COMMAND ----------

-- Undrop the orders_man table - this only works during the retention policy's time (which is usually set to 24 hrs)
UNDROP TABLE sparksql_cata.sparksql_schema.order_man;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### External Tables

-- COMMAND ----------

-- Create the orders_ext table
CREATE TABLE sparksql_cata.sparksql_schema.order_ext
LOCATION 'abfss://sparksql@storaccsqlforbigde.dfs.core.windows.net/source/orders_ext'
AS (
    SELECT *
    FROM orders_temp
);