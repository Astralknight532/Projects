-- Databricks notebook source
SELECT *
FROM sparksql_cata.sparksql_schema.orders_ext;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Filtering SQL tables

-- COMMAND ----------

-- Filter the table for data where the product_category is Fashion
SELECT *
FROM sparksql_cata.sparksql_schema.orders_ext
WHERE product_category = 'Fashion';

-- COMMAND ----------

-- MAGIC %python
-- MAGIC # Create a dataframe from the data in the external orders table using the SQL query from the previous notebook cell
-- MAGIC df_test = spark.sql(
-- MAGIC '''
-- MAGIC SELECT *
-- MAGIC FROM sparksql_cata.sparksql_schema.orders_ext
-- MAGIC WHERE product_category = 'Fashion';
-- MAGIC '''
-- MAGIC )