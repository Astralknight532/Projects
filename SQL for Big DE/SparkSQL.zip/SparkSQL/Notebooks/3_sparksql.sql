-- Databricks notebook source
-- MAGIC %md
-- MAGIC # **UPSERT - MERGE**
-- MAGIC - UPSERT -> UPDATE + INSERT

-- COMMAND ----------

-- MAGIC %python
-- MAGIC # Create a dataframe to be the source of the data to be merged/upserted into the target table - need a primary key column for the matching to merge/upsert
-- MAGIC source_df = spark.read.table("sparksql_cata.sparksql_schema_order_man")
-- MAGIC
-- MAGIC # Create a SQL temp view to use for the actual merge/upsert
-- MAGIC source_df.createOrReplaceTempView("order_source")
-- MAGIC
-- MAGIC # Another way to get the data from the source dataframe into Spark SQL
-- MAGIC spark.sql(
-- MAGIC     '''
-- MAGIC     SELECT *
-- MAGIC     FROM {orders_temp}
-- MAGIC     ''',
-- MAGIC     orders_temp = source_df
-- MAGIC ) # can add .display() to display the data

-- COMMAND ----------

-- Perform the actual merge using the temp view as the source table and order_ext as the destination/target table
MERGE INTO sparksql_cata.sparksql_schema.order_ext AS tgt
USING order_source AS src
ON tgt.order_id = src.order_id
WHEN MATCHED THEN
UPDATE SET *
WHEN NOT MATCHED THEN
INSERT *;