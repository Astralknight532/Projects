-- Databricks notebook source
-- MAGIC %md
-- MAGIC

-- COMMAND ----------

-- MAGIC %md
-- MAGIC # **FUNCTIONS**
-- MAGIC - user-defined functions
-- MAGIC - user-defined table functions

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Scalar Functions - UDF

-- COMMAND ----------

-- User-defined functions example - will be registered with the Unity Catalog for other users to use
CREATE OR REPLACE FUNCTION sparksql_cata.sparksql_schema.discount_price(p_price DECIMAL(10, 2))
RETURNS DECIMAL(10, 2)
LANGUAGE SQL
RETURN p_price * 0.90

-- COMMAND ----------

SELECT price_per_unit AS Normal_Price_Per_Unit,
    sparksql_cata.sparksql_schema.discount_price(price_per_unit) AS Discounted_Price_Per_Unit
FROM sparksql_cata.sparksql_schema.orders_ext

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Table Functions - UDTF

-- COMMAND ----------

-- User-defined table functions example - will be registered with the Unity Catalog for other users to use
CREATE OR REPLACE FUNCTION sparksql_cata.sparksql_schema.category_filter(p_category STRING)
RETURNS TABLE
LANGUAGE SQL
RETURN (
    SELECT *
    FROM sparksql_cata.sparksql_schema.order_ext
    WHERE product_category = p_category
)