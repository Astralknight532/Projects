-- Databricks notebook source
-- MAGIC %md
-- MAGIC # **DYNAMIC DATA MASKING**

-- COMMAND ----------

SELECT *
FROM sparksql_cata.sparksql_schema.orders_ext;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Mask Function

-- COMMAND ----------

-- Creating an example dynamic data mask for the user_id column
CREATE OR REPLACE FUNCTION sparksql_cata.sparksql_schema.dynamic_mask(p_user_id STRING)
RETURN
CASE
    WHEN is_account_group_member('admins_test') THEN p_user_id
    ELSE '******'
END;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Applying the mask function to the column user_id

-- COMMAND ----------

-- Apply the dynamic data mask function to the column user_id
ALTER TABLE sparksql_cata.sparksql_schema.orders_ext
ALTER COLUMN user_id SET MASK sparksql_cata.sparksql_schema.dynamic_mask;

-- COMMAND ----------

SELECT *
FROM sparksql_cata.sparksql_schema.orders_ext;