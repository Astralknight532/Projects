-- Databricks notebook source
-- MAGIC %md
-- MAGIC # **Row Level Security/Filters**

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Mapping Table

-- COMMAND ----------

-- Create the mapping table - define the rules determining what data that users will have access to
CREATE TABLE sparksql_cata.sparksql_schema.map_table (
    payment_category STRING,
    email STRING
);

-- Check the orders_ext table
SELECT *
FROM sparksql_cata.sparksql_schema.orders_ext;

-- Insert the values into the map table
INSERT INTO sparksql_cata.sparksql_schema.map_table
VALUES ('Credit Card', 'moonfrost532@gmail.com'),
('Debit Card', 'moonfrost532@gmail.com'),
('PayPal', 'newuser@gmail.com'),
('UPI', 'newuser@gmail.com');

-- Check the map_table table
SELECT *
FROM sparksql_cata.sparksql_schema.map_table;

-- Use the current_user() function to get rows only for a specific user
SELECT *
FROM sparksql_cata.sparksql_schema.map_table
WHERE email = current_user() AND payment_category = 'Credit Card'; -- if the payment category value is changed to UPI, then no results will be returned

-- Create a function that will be run on the payment_category column each time to determine which rows a user can see (row-level security)
-- This query returns a Boolean value - this will be useful in the function for row-level security
SELECT EXISTS
FROM (
    SELECT *
    FROM sparksql_cata.sparksql_schema.map_table
    WHERE email = current_user() AND payment_category = 'Credit Card'
);

-- Create the actual function that returns a Boolean value
CREATE OR REPLACE FUNCTION sparksql_cata.sparksql_schema.rowlevel_security(p_payment_method STRING)
RETURNS BOOLEAN
LANGUAGE SQL
RETURN (
    EXISTS (
        SELECT *
        FROM sparksql_cata.sparksql_schema.map_table
        WHERE email = current_user() AND payment_category = p_payment_method
    )
)

-- Apply the row-level security function to the payment_category column
ALTER TABLE sparksql_cata.sparksql_schema.orders_ext
SET ROW FILTER sparksql_cata.sparksql_schema.rowlevel_security ON (payment_method);