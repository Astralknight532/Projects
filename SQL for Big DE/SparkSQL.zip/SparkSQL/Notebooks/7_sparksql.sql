-- Databricks notebook source
-- MAGIC %md
-- MAGIC # Delta Lake With Spark SQL

-- COMMAND ----------

SELECT *
FROM sparksql_cata.sparksql_schema.orders_ext; -- use orders_man once it has been properly created

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### DML Operations

-- COMMAND ----------

UPDATE sparksql_cata.sparksql_schema.orders_ext
SET product_category = 'GenZ Fashion'
WHERE product_category = 'Fashion';

-- COMMAND ----------

-- Use EXTENDED with DESCRIBE to examine the orders_ext table
DESCRIBE EXTENDED sparksql_cata.sparksql_schema.orders_ext;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Data Versioning
-- MAGIC - helps you find certain rows & track changes to the tables)

-- COMMAND ----------

DELETE FROM sparksql_cata.sparksql_schema.orders_ext
WHERE order_id = '1001';

-- COMMAND ----------

DESCRIBE HISTORY sparksql_cata.sparksql_schema.orders_ext; -- Check the history details of the orders_ext table

-- COMMAND ----------

SELECT *
FROM sparksql_cata.sparksql_schema.orders_ext;

-- COMMAND ----------

CREATE TABLE sparksql_cata.sparksql_schema.orders_ext
LOCATION 'abfss://sparksql@storacc.dfs.core.windows.net/orders_new';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Time Travel - used for rolling back queries

-- COMMAND ----------

RESTORE sparksql_cata.sparksql_schema.orders_ext TO VERSION AS OF 3; -- can also perform rollback in SQL on the delta lake tables - useful when there is no table available -> replace the SQL table name with the delta lake location surrounded by backticks & preceded by delta. (``)

-- COMMAND ----------

DESCRIBE HISTORY delta.`abfss://sparksql@storacc.dfs.core.windows.net/source/orders_new`;
RESTORE delta.`abfss://sparksql@storacc.dfs.core.windows.net/source/orders_new` TO VERSION AS OF 0;